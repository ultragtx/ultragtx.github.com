Teamarks OSX How To
===================

#compile:

* Open teamarks.xcworkspace 
* Set build target to teamarks
* Build and run

#install

* build
* in teamarks project, find a group(folder) named "Products"
* in this group you will see "teamarks.app"
* right click >> show in finder >> copy to where you want

#how to use

currnt global hotkey: ctrl + v

1. open the app (a status bar icon will show up)
	* copy the url you want
	* tap status bar >> share or Ctrl + v to open a share window
	* the url will be loaded in the text field and title will be loaded from internet soon 	
2. open the app (a status bar icon will show up)
	* tap status bar >> share or Ctrl + v to open a share window
	* enter url in url field and press enter then title will be loaded from internet soon 	


##eg.

* Copy Text: 

		Safari Books Online (www.safaribooksonline.com) is an on-demand digital library that delivers expert content in both book and video form from the world’s leading authors in technology and business.
	
* title: load from internet

		Safari Books Online |

* url: find in the copy text

		http://www.safaribooksonline.com

* text:

		) is an on-demand digital library that delivers expert content in both book and video form from the world’s leading authors in technology and business.



	